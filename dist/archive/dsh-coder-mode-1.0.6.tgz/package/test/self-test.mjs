/**
 * 码农模式自检：不需要 Harness 运行时，用桩 ctx 验证注册形状、扫描逻辑、上下文渲染与两个工具。
 * 运行：node test/self-test.mjs [要扫描的目录]
 */
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { Config, apply, inject, name } from '../index.js';
import { backupResultText, policyText, probeResultText, workspaceContextText } from '../policy.js';
import { scanAncestors, scanForProjects } from '../rules.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = path.dirname(here);
const scanTarget = process.argv[2] ?? path.resolve(packageRoot, '..');

/** 收集注册结果的桩上下文。 */
function createStubContext() {
  const registered = { sections: [], contexts: [], tools: [], events: [], effects: [] };
  const ctx = {
    logger: { warn() {}, info() {}, error() {} },
    effect(factory, label) {
      const dispose = factory();
      registered.effects.push({ label, dispose: typeof dispose === 'function' ? dispose : () => {} });
      return () => {};
    },
    on(event, listener) {
      registered.events.push({ event, listener });
      return () => {};
    },
    systemPrompt: {
      section(section) {
        registered.sections.push(section);
        return () => {};
      },
      context(context) {
        registered.contexts.push(context);
        return () => {};
      }
    },
    tools: {
      register(definition) {
        registered.tools.push(definition);
        return () => {};
      }
    }
  };
  return { ctx, registered };
}

/** 构造一个只带 id 与 cwd 的假 Agent。 */
function fakeAgent(cwd, id = 'test-session') {
  return { id, session: { header: { cwd } } };
}

/** 假工具执行上下文。 */
function fakeExec(cwd) {
  return { agent: fakeAgent(cwd), signal: new AbortController().signal };
}

let passed = 0;
async function check(label, fn) {
  await fn();
  passed += 1;
  console.log(`  ok - ${label}`);
}

const toolNamed = (tools, toolName) => tools.find((tool) => tool.name === toolName);

console.log('码农模式自检');
console.log(`  插件：${name}，inject=[${inject.join(', ')}]`);

await check('配置默认值与非法值', () => {
  const ok = Config['~standard'].validate({ language: 'en', scanDepth: 1 });
  assert.equal(ok.issues, undefined);
  assert.equal(ok.value.language, 'en');
  assert.equal(ok.value.scanDepth, 1);
  assert.equal(ok.value.maxScanDirs, 80);
  assert.ok(Array.isArray(Config['~standard'].validate({ language: 'fr' }).issues));
  assert.ok(Array.isArray(Config['~standard'].validate({ nope: 1 }).issues));
  assert.equal(Config['~standard'].validate(undefined).value.language, 'zh');
});

const { ctx, registered } = createStubContext();
apply(ctx, {});

await check('注册了 1 个策略段、1 个上下文、2 个工具', () => {
  assert.equal(registered.sections.length, 1);
  assert.equal(registered.sections[0].name, 'coder-mode:policy');
  assert.ok(policyText('zh').length > 200);
  assert.equal(registered.contexts.length, 1);
  assert.equal(registered.contexts[0].name, 'coder-mode:workspace');
  assert.deepEqual(registered.tools.map((tool) => tool.name).sort(), ['coder_backup', 'coder_project_probe']);
  assert.ok(registered.events.some((entry) => entry.event === 'agent/disposed'));
});

await check('工具定义带有合法的 output 与 parameters', () => {
  for (const tool of registered.tools) {
    assert.equal(typeof tool.description, 'string');
    assert.equal(typeof tool.output?.render, 'function');
    assert.equal(tool.output?.schema?.type, 'object');
    assert.equal(tool.parameters?.type, 'object');
    assert.equal(typeof tool.execute, 'function');
  }
});

await check(`扫描 ${scanTarget} 能识别出项目标记`, () => {
  const scan = scanForProjects(scanTarget, { depth: 2, maxDirs: 80 });
  assert.ok(scan.scanned > 0);
  assert.equal(scan.errors.length, 0, `扫描报错：${JSON.stringify(scan.errors)}`);
  assert.ok(scan.found.length > 0, '未发现任何项目标记');
  const labels = scan.found.flatMap((hit) => hit.matches.map((match) => match.label));
  assert.ok(labels.includes('Godot Engine'), `命中的标记：${labels.join(', ')}`);
  const entry = scan.found
    .flatMap((hit) => hit.matches.map((match) => ({ dir: hit.dir, match })))
    .find((item) => item.match.id === 'godot');
  const declared = readFileSync(path.join(entry.dir, 'project.godot'), 'utf8')
    .match(/config\/features=PackedStringArray\(\s*"([^"]+)"/)[1];
  assert.equal(entry.match.version, declared);
  assert.ok(entry.match.docs[0].startsWith('https://docs.godotengine.org'));
});

await check('工作区上下文渲染出项目、版本与官方地址', () => {
  const scan = scanForProjects(scanTarget, { depth: 2, maxDirs: 80 });
  const text = workspaceContextText({ cwd: scanTarget, depth: 2, scan }, 'zh');
  assert.ok(text.includes('形态：项目'), text);
  assert.ok(text.includes('Godot Engine'), text);
  assert.ok(text.includes('https://docs.godotengine.org'), text);
  assert.ok(text.includes('https://github.com/godotengine/godot'), text);
});

await check('无项目标记时上下文要求先征求同意', () => {
  const empty = { root: scanTarget, scanned: 1, truncated: false, found: [], errors: [] };
  const text = workspaceContextText({ cwd: scanTarget, depth: 2, scan: empty }, 'zh');
  assert.ok(text.includes('疑似「杂项文件'), text);
  assert.ok(text.includes('consent: true'), text);
});

await check('探针：未获同意时不执行上溯', async () => {
  const probe = toolNamed(registered.tools, 'coder_project_probe');
  const cwd = path.join(scanTarget, 'animals-fight');
  const result = await probe.execute({ includeParents: true, consent: false }, fakeExec(cwd));
  assert.equal(result.status, 'consent-required');
  assert.ok(result.text.includes('未执行'), result.text);
  assert.equal('ancestors' in result, false);
});

await check('探针：获同意后真的上溯并报告结果', async () => {
  const probe = toolNamed(registered.tools, 'coder_project_probe');
  const cwd = path.join(scanTarget, 'animals-fight');
  const result = await probe.execute({ includeParents: true, consent: true, parentLevels: 3 }, fakeExec(cwd));
  assert.equal(result.status, 'project');
  assert.ok(Array.isArray(result.ancestors) && result.ancestors.length > 0);
  assert.ok(result.text.includes('向上查找'), result.text);
});

await check('探针：向上查找找到项目根时会写进上下文', async () => {
  const probe = toolNamed(registered.tools, 'coder_project_probe');
  const scan = scanForProjects(scanTarget, { depth: 0, maxDirs: 8 });
  assert.equal(scan.found.length, 0, '本目录不应直接命中标记（标记在子目录里）');
  const result = await probe.execute({ depth: 0 }, fakeExec(scanTarget));
  assert.equal(result.status, 'no-known-project-marker');
  const text = probeResultText({
    cwd: scanTarget,
    target: scanTarget,
    depth: 0,
    scan,
    escapesWorkingDirectory: false
  }, 'zh');
  assert.ok(text.includes('疑似「杂项文件'), text);
  assert.ok(text.includes('includeParents:true, consent:true'), text);
  const withParents = await probe.execute({ includeParents: true, consent: true, parentLevels: 2 }, fakeExec(scanTarget));
  const contextText = workspaceContextText({
    cwd: scanTarget,
    depth: 0,
    scan,
    ancestors: withParents.ancestors
  }, 'zh');
  assert.ok(contextText.includes('向上查找'), contextText);
});

await check('探针：更浅的一次探测不会把工作区上下文降级成"杂项"', async () => {
  const probe = toolNamed(registered.tools, 'coder_project_probe');
  const agent = fakeAgent(scanTarget, 'context-downgrade-session');
  const render = () => registered.contexts[0].text({ agent });
  const before = render();
  assert.ok(before.includes('形态：项目'), before);
  assert.ok(before.includes('Godot Engine'), before);
  await probe.execute({ depth: 0 }, { agent, signal: new AbortController().signal });
  const after = render();
  assert.ok(after.includes('形态：项目'), `depth:0 探测后上下文被降级：\n${after}`);
  assert.ok(after.includes('Godot Engine'), after);
});

await check('探针：不存在的路径直接报错', async () => {
  const probe = toolNamed(registered.tools, 'coder_project_probe');
  await assert.rejects(
    () => probe.execute({ path: 'definitely-not-here-9f3a' }, fakeExec(scanTarget)),
    /路径不可读/
  );
});

await check('探针：文件路径被拒绝', async () => {
  const probe = toolNamed(registered.tools, 'coder_project_probe');
  await assert.rejects(
    () => probe.execute({ path: 'project.godot' }, fakeExec(path.join(scanTarget, 'animals-fight'))),
    /不是目录/
  );
});

await check('备份：文件+目录只复制，覆盖与失败都如实报告', async () => {
  const backup = toolNamed(registered.tools, 'coder_backup');
  const sandbox = mkdtempSync(path.join(tmpdir(), 'coder-mode-test-'));
  try {
    const sourceDir = path.join(sandbox, 'project');
    mkdirSync(path.join(sourceDir, 'scenes'), { recursive: true });
    const sourceFile = path.join(sourceDir, 'scenes', 'main.tscn');
    const content = '[gd_scene]\n';
    writeFileSync(sourceFile, content, 'utf8');
    const result = await backup.execute(
      { paths: ['project/scenes/main.tscn', 'project/scenes', 'project/missing.tscn'], reason: '自检' },
      fakeExec(sandbox)
    );
    assert.equal(result.backedUp.length, 1);
    assert.equal(result.coveredByParent.length, 1);
    assert.equal(result.failures.length, 1);
    assert.match(result.failures[0].error, /ENOENT/);
    const dirEntry = result.backedUp[0];
    assert.equal(dirEntry.kind, 'directory');
    assert.equal(readFileSync(path.join(dirEntry.backup, 'main.tscn'), 'utf8'), content);
    assert.equal(readFileSync(sourceFile, 'utf8'), content, '原文件必须未被修改');
    assert.ok(readFileSync(path.join(result.root, 'BACKUP-MANIFEST.txt'), 'utf8').includes('自检'));
    const text = backupResultText({ root: result.root, backups: result.backedUp, failures: result.failures, covered: result.coveredByParent, reason: '自检' }, 'zh');
    assert.ok(text.includes('备份完成'), text);
    assert.ok(text.includes('失败条目'), text);
    assert.ok(text.includes('未重复复制'), text);
  } finally {
    rmSync(sandbox, { recursive: true, force: true });
  }
});

await check('备份：空 paths 直接报错', async () => {
  const backup = toolNamed(registered.tools, 'coder_backup');
  await assert.rejects(() => backup.execute({ paths: [] }, fakeExec(scanTarget)), /至少需要一个非空路径/);
});

await check('备份：工作目录之外的文件落到 _external', async () => {
  const backup = toolNamed(registered.tools, 'coder_backup');
  const outside = mkdtempSync(path.join(tmpdir(), 'coder-mode-outside-'));
  const sandbox = mkdtempSync(path.join(tmpdir(), 'coder-mode-test-'));
  try {
    const externalFile = path.join(outside, 'notes.txt');
    writeFileSync(externalFile, 'external\n', 'utf8');
    const result = await backup.execute({ paths: [externalFile] }, fakeExec(sandbox));
    assert.equal(result.backedUp.length, 1);
    assert.ok(result.backedUp[0].backup.includes('_external'), result.backedUp[0].backup);
    assert.equal(readFileSync(result.backedUp[0].backup, 'utf8'), 'external\n');
  } finally {
    rmSync(sandbox, { recursive: true, force: true });
    rmSync(outside, { recursive: true, force: true });
  }
});

await check('策略段包含 5 条规则关键词', () => {
  const zh = policyText('zh');
  for (const key of ['向上层目录查找项目根', '官方文档', '不知道', '缺失', 'coder_backup']) {
    assert.ok(zh.includes(key), `策略段缺少关键词：${key}`);
  }
  const en = policyText('en');
  assert.ok(en.includes('consent') && en.includes('coder_backup'));
});

await check('祖先扫描：从工作区根继续向上不会崩', () => {
  const chain = scanAncestors(scanTarget, 4);
  assert.ok(Array.isArray(chain));
  for (const entry of chain) assert.equal(typeof entry.dir, 'string');
});

console.log(`\n全部通过：${passed} 项检查。`);
